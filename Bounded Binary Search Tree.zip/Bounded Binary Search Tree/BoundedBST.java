import java.util.*;
import java.io.*;

/*
Author: Nathan LaBeff
Last Edited: 10/09/23
 */


public class BoundedBST {
    //Implements an BST tree of (int, name) pairs stored in parallel arrays
    //There are no duplicates in the tree
    private int root; //the index of the root node
    private int free; //the first node in the free list
    private int left[];
    private int key[];
    private String name[];
    private int right[];
    private int maxIndexUsed;

    public BoundedBST(int size) {
        root = -1;
        free = -1;
        left = new int[size];
        key = new int[size];
        name = new String[size];
        right = new int[size];
        maxIndexUsed = -1;
    }

    public boolean full() {
        return maxIndexUsed == key.length-1 && free == -1;
    }

    public void insert(int k, String s) {
        //PRE: the tree is not full
        //if k is not in the tree insert (k,s) otherwise the tree does not change
        //if space is available in the free list then the first item on the free list
        //must be used to store the new node otherwise use the space at maxIndexUsed+1
        if(root == -1){
            key[maxIndexUsed+1] = k;
            name[maxIndexUsed+1] = s;
            left[maxIndexUsed+1] = -1;
            right[maxIndexUsed+1] = -1;
            root = maxIndexUsed+1;
            maxIndexUsed++;
        }else{
            insertRecursive(root, k, s);
        }

    }

    public void print() {
        //print a comma delimited list of pairs, (key, name),of values in the tree in
        //ascending order of the key on one line. a newline should be printed at the end of the
        //line for example (10,Hodgkin), (25,Pauling), (40,Mendeleev),(50,Pasteur), (60,Avogadro),
        //70,Boyle), (75,Curie), (80,Rutherford)
        printRecursive(root);
        System.out.println();

    }
    public void remove(int k) {
        //if k is in the tree remove the node with key k and add the node containing k to the free list
        //if k is not in the tree do nothing
        root = removeRecursive(root, k);


    }
    public String findName(int k) {
        //if k is in the tree return the name associated with k otherwise return null
        int curIndex = root;
        while(curIndex != -1){
            if (k == key[curIndex]){
                return name[curIndex];
            } else if (k < key[curIndex]){
                curIndex = left[curIndex];
            } else {
                curIndex = right[curIndex];
            }
        }
        return null;
    }

    // Recursive helper methods called by above methods to assist in removal and insertion of children

    /**
     * A recursive helper method called by insert() to assist in insertion of children.
     * @param curIndex the current index
     * @param k the key to insert
     * @param s the name to insert
     */
    private void insertRecursive(int curIndex, int k, String s){

        //If the curIndex is greater than the size of the tree insert the value.
        //If value is less than the curIndex, it recursively calls the method going to the left.
        //Other-wise it calls the method going to the right
        if (k < key[curIndex]) {
            if (left[curIndex] == -1) {
                int newIndex = getNewIndex();
                left[curIndex] = newIndex;
                key[newIndex] = k;
                name[newIndex] = s;
                left[newIndex] = -1;
                right[newIndex] = -1;
            } else {
                insertRecursive(left[curIndex], k, s);
            }
        } else if (k > key[curIndex]) {
            if (right[curIndex] == -1) {
                int newIndex = getNewIndex();
                right[curIndex] = newIndex;
                key[newIndex] = k;
                name[newIndex] = s;
                left[newIndex] = -1;
                right[newIndex] = -1;
            } else {
                insertRecursive(right[curIndex], k, s);
            }
        }
    }

    /**
     * A recursive helper method called by remove() to assist in removal of children.
     * @param curIndex the current index
     * @param k the key to remove
     * @return the index of the current node
     */
    private int removeRecursive(int curIndex,int k){
        //If the curIndex is -1, it returns -1.
        //If the value is less than the curIndex, it recursively calls the method going to the left.
        //Other-wise it recursively calls the method going to the right
        if (curIndex == -1){
            return -1;
        }
        if (k < key[curIndex]){
            left[curIndex] = removeRecursive(left[curIndex], k);
        }else if( k > key[curIndex]){
            right[curIndex] = removeRecursive(right[curIndex], k);
        } else {
            if (left[curIndex] == -1){
                int newIndex = curIndex;
                curIndex = right[curIndex];
                freeIndex(newIndex);
            } else if(right[curIndex] == -1){
                int newIndex = curIndex;
                curIndex = left[curIndex];
                freeIndex(newIndex);
            } else {
                int minIndex = findMinIndex(right[curIndex]);
                key[curIndex] = key[minIndex];
                name[curIndex] = name[minIndex];
                right[curIndex] = removeRecursive(right[curIndex], key[minIndex]);
            }
        }
        return curIndex;
    }
    /**
     * A recursive helper method called by print() to assist in printing the tree.
     * @param curIndex the current index
     */
    private void printRecursive(int curIndex) {
        if (curIndex != -1){
            printRecursive(left[curIndex]);
            System.out.print("(" + key[curIndex] + "," + name[curIndex] + ")");
            if (right[curIndex] != -1) {
                System.out.print(", ");
            }
            printRecursive(right[curIndex]);
        }
    }

    //Helpers of the helper methods.
    /**
     * A helper method that returns a new index for a new node in the tree.
     * If the free index is not -1, it returns the free index and sets the free index to the left index.
     * Otherwise, it increments maxIndexUsed and returns it.
     * @return a new index for a new node in the tree
     */
    private int getNewIndex() {
        if (free != -1){
            int newIndex = free;
            free = left[free];
            return newIndex;
        } else {
            maxIndexUsed++;
            return maxIndexUsed;
        }

    }

    /**
     * A helper method that finds the index of the node with the minimum key in the subtree rooted at curIndex.
     * @param curIndex the current index
     * @return the index of the node with the minimum key in the subtree rooted at curIndex
     */
    private int findMinIndex(int curIndex) {
        while (left[curIndex] != -1){
            curIndex = left[curIndex];
        }
        return curIndex;
    }
    /**
     * A helper method that adds the node at index to the free list.
     * @param index the index of the node to add to the free list
     */
    private void freeIndex(int index) {
        //Sets the left index to the free index and then sets the free index to the index.
        left[index] = free;
        free = index;
    }




}