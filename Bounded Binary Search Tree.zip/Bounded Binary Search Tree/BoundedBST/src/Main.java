public class Main {
    public static void main(String[] args) {
        BoundedBST bst = new BoundedBST(10);

        bst.insert(50, "Pasteur");
        bst.insert(25, "Pauling");
        bst.insert(75, "Curie");
        bst.insert(10, "Hodgkin");
        bst.insert(40, "Mendeleev");
        bst.insert(60, "Avogadro");
        bst.insert(80, "Rutherford");
        bst.insert(70, "Boyle");

        bst.print();

        bst.remove(25);
        bst.remove(80);

        bst.print();

        System.out.println(bst.findName(40));
        System.out.println(bst.findName(80));
    }
}