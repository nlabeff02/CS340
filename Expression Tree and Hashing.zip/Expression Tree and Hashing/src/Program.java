import java.io.*;
import java.util.*;

public class Program {
    
    private Hashtable<String, Integer> varMemory;
    private ArrayList<ExpressionTree> trees;
    
    public Program(String fname, int hashSize) throws IOException {
    //The constuctor must build an expression tree for each statement in the program
        varMemory = new Hashtable<>(hashSize);
        trees = new ArrayList<>();

        BufferedReader reader = new BufferedReader(new FileReader(fname));
        String line;
        while ((line = reader.readLine()) != null) {
            trees.add(new ExpressionTree(line));
        }
        reader.close();
    }
    
    public void run() {
    //Execute each statement in the program
    //Each statement is evaluated using ExpressionTree’s eval function
        for (ExpressionTree tree : trees) {
            tree.eval(varMemory);
        }
    }
    
    public void printPostfix() {
    //Prints the statements is postfix notation
        for (ExpressionTree tree : trees) {
            System.out.println(tree.postfix());
        }
    }
    
    public void printVars() {
    //PRE: the program has been run
    //Prints the current values of the variables
        for (String key : varMemory) {
            System.out.println(key + " = " + varMemory.get(key));
        }
    }
    
    public static void main(String args[]) throws IOException{
    //Simple test driver
        Program p = new Program(args[0], Integer.parseInt(args[1]));
        p.printPostfix();
        p.run();
        p.printVars();
        
    }
}
