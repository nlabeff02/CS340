import java.io.*;
import java.util.*;

public class Hashtable<K, V> implements Iterable<K> {
    //implements a separate chaining hash table
    private class Node {
        K key;
        V value;
        Node next;
        private Node(K key, V value, Node n) {
            this.key = key;
            this.value = value;
            next = n;
        }
    }
    
    private ArrayList<Node> table;
    private int tableSize;

    
    private int hash(K key) {
        return (Math.abs(key.hashCode()))%tableSize;
    }

    private final float loadFactorThreshold = 0.75f;
    private int size;

    public Hashtable(int initialCapacity) {
        table = new ArrayList<>(initialCapacity);
        for (int i = 0; i < initialCapacity; i++) {
            table.add(null);
        }
        tableSize = initialCapacity;
        size = 0;
    }
    
    public V get(K key) {
    //if key is not in the table return null
    //otherwise return the value associated with key
        int index = hash(key);
        Node head = table.get(index);

        while (head != null) {
            if (head.key.equals(key)) {
                return head.value;
            }
            head = head.next;
        }

        return null;

    }


    public void put(K key,V value) {
    //if key is in the table update the value associated with key
    //othewise insert key and its associated value into the table
        int index = hash(key);
        Node head = table.get(index);

        while (head != null) {
            if (head.key.equals(key)) {
                head.value = value;
                return;
            }
            head = head.next;
        }
        size++;
        head = table.get(index);
        Node newNode = new Node(key, value, head);
        table.set(index, newNode);

        if((1.0 * size) / tableSize >= loadFactorThreshold){
            resize();
        }
    }
    // Method to resize the hash table
    private void resize() {
        ArrayList<Node> oldTable = table;
        tableSize = tableSize * 2;
        table = new ArrayList<>(tableSize);
        size = 0;
        for (int i = 0; i < tableSize; i++) {
            table.add(null);
        }

        for (Node headNode : oldTable) {
            while (headNode != null) {
                put(headNode.key, headNode.value);
                headNode = headNode.next;
            }
        }
    }

    public class HashIterator implements Iterator<K> {
        private int currentBucket;
        private Node currentNode;

        public HashIterator() {
            currentBucket = 0;
            currentNode = null;
        }
        public K next() {
            if (currentNode != null && currentNode.next != null) {
                currentNode = currentNode.next;
            } else {
                while (currentBucket < tableSize && (table.get(currentBucket) == null)) {
                    currentBucket++;
                }

                if (currentBucket < tableSize) {
                    currentNode = table.get(currentBucket);
                }
            }

            if (currentNode != null) {
                return currentNode.key;
            } else {
                throw new NoSuchElementException("Element doesn't exist.");
            }
        }

        public boolean hasNext() {
            if (currentNode != null && currentNode.next != null) {
                return true;
            }

            currentBucket++;

            while (currentBucket < tableSize) {
                if (table.get(currentBucket) != null) {
                    currentNode = table.get(currentBucket);
                    return true;
                }
                currentBucket++;
            }
            return false;
        }

        public void remove() {
            //optional method not implemented
            //it would not behoove to do remove
        }
    }

    public V getOrDefault(K key, V defaultValue) {
        //new implementation to get the getOrDefault method of the Hash class
        V value = get(key);
        return (value != null) ? value : defaultValue;
    }
    public Iterator<K> iterator() {
        return new HashIterator();
    }

}
