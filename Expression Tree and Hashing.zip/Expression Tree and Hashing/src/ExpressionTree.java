import java.util.Stack;

public class ExpressionTree {
    private class Node {
        Node left;
        String data;
        Node right;

        private Node(Node L, String d, Node R) {
            left = L;
            data = d;
            right = R;
        }
    }

    private Node root;
    private String variable;

    public ExpressionTree(String exp) {
        //PRE: exp is an syntactically correct infix expression
        //     in the expression the first token is a variable and the
        //     second token is a = sign
        //Build an expression tree from exp
        variable = exp.substring(0, exp.indexOf("=")).trim();

        Stack<Node> stack = new Stack<>();
        String postfix = convertToPostfix(exp);

        for (String token : postfix.split(" ")) {
            if (isOperator(token)) {
                if (isUnaryOperator(token)) { // Check if it's a unary operator
                    Node right = stack.pop();
                    stack.push(new Node(null, token, right));
                } else {
                    Node right = stack.pop();
                    Node left = stack.isEmpty() ? null : stack.pop(); // Check if left operand exists
                    stack.push(new Node(left, token, right));
                }
            } else {
                stack.push(new Node(null, token, null));
            }
        }

        root = stack.pop();
    }

    public String postfix() {
        //return the string representation of the expression tree in postfix notation
        return variable + " " + toPostfix(root) + "=";
    }

    private String toPostfix(Node node) {
        if (node == null) {
            return "";
        }
        return toPostfix(node.left) + toPostfix(node.right) + node.data + " ";
    }

    public void eval(Hashtable<String, Integer> varMemory) {
        //evaluate the expression tree
        //varMemory contains values for variables

        int result = evalTree(root, varMemory);

        // Store the result in varMemory with the variable as the key
        varMemory.put(variable, result);
    }

    private int evalTree(Node node, Hashtable<String, Integer> varMemory) {
        if (node == null) {
            return 0;
        }
        try {
            // Directly parse if it's a numeric value
            return Integer.parseInt(node.data);
        } catch (NumberFormatException e) {
            // If it's an operator, evaluate its operands and apply the operation
            if (isOperator(node.data)) {
                int right = evalTree(node.right, varMemory);
                if (node.data.equals("!")) { // Check for unary minus
                    return right * -1;
                } else {
                    int left = evalTree(node.left, varMemory);
                    return applyOperation(node.data, left, right);
                }
            } else {
                // If it's not numeric, then it's a variable; get the value from varMemory
                return varMemory.getOrDefault(node.data, 0); // Default to 0 if var not found
            }
        }
    }

    /**
     * Converts an infix expression to a postfix expression.
     * It handles operator precedence, associativity, and parentheses,
     * ensuring the generated postfix expression is correctly ordered.
     *
     * @param infix The infix expression to be converted.
     * @return The converted postfix expression.
     */
    private String convertToPostfix(String infix) {
        // First, skip the variable part before "=" to focus on the expression
        int equalsIndex = infix.indexOf("=");
        infix = infix.substring(equalsIndex + 1).trim(); // Start conversion after equals

        Stack<String> stack = new Stack<>();
        StringBuilder postfix = new StringBuilder();
        String[] tokens = infix.split(" ");
        String previousToken = null;
        for (String token : tokens) {
            // If it's an open bracket, just push it onto the stack.
            if (isUnaryMinus(token, previousToken)) {
                stack.push("!");
            } else {
                if (token.equals("(")) {
                    stack.push(token);

                } else if (token.equals(")")) {

                    while (!stack.isEmpty() && !stack.peek().equals("(")) {
                        // For a closing bracket, pop everything until we hit an open bracket.
                        postfix.append(stack.pop()).append(" ");
                    }
                    if (!stack.isEmpty() && stack.peek().equals("(")) {
                        stack.pop(); // Get rid of the opening bracket.
                    }
                } else if (isOperand(token)) {
                    // If it's a number or variable, add it to the postfix string.
                    postfix.append(token).append(" ");

                } else if (isOperator(token)) {
                    // For operators, we get a bit tricky. We need to consider precedence.
                    while (!stack.isEmpty() && toPop(stack.peek(), token)) {
                        postfix.append(stack.pop()).append(" ");
                    }
                    stack.push(token);// Then, push the current operator onto the stack.
                }
            }
            previousToken = token;
        }

        while (!stack.isEmpty()) {
            // At the end, pop any remaining operators onto the postfix string.
            postfix.append(stack.pop()).append(" ");
        }

        return postfix.toString().trim();
    }

    private boolean isOperand(String token) {
        return !isOperator(token);
    }

    private int applyOperation(String operator, int left, int right) {
        switch (operator) {
            case "+":
                return left + right;
            case "-":
                return left - right;
            case "*":
                return left * right;
            case "/":
                return left / right;
            case "%":
                return left % right;
            case "!":
                return -right;
            case "^":
                return (int) Math.pow(left, right);
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }

    private boolean isUnaryMinus(String token, String previousToken) {
        if (!token.equals("-")) {
            return false;
        }
        return previousToken == null || previousToken.equals("(") || isOperator(previousToken);
    }

    private boolean isUnaryOperator(String token) {
        return token.equals("!");
    }

    private boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/") || token.equals("%") || token.equals("^") || token.equals("!");
    }


    private boolean toPop(String st, String cur) {

        Stack<String> st1 = new Stack<String>();
        st1.push(st);

        if(st1.isEmpty() || cur.equals("(")) {
            //Just add operator to stack
            return false;
        }

        //Look at operator at top of stack
        String top = st1.peek();
        if(cur.equals(")") && top.equals("(")) {
            return false;
        }
        if(cur.equals(")")) {
            return true;
        }
        int curLevel = getPrecedence(cur);
        int topLevel = getPrecedence(top);

        if(getPrecedence(cur) < getPrecedence(top)) {
            return true;
        }
        if(curLevel == topLevel && isLeftAssociative(cur)) {
            return true;
        }
        //Op has higher precedence than top or op and top have equal precedence and are right associative
        return false;
    }

    private int getPrecedence(String operator) {
        // Return the precedence of the operator
        // For example, *, /, % have higher precedence than +, -
        switch (operator) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
            case "%":
                return 2;
            case "^":
                return 3;
            case "!": // Unary minus which we converted earlier
                return 4;
            default:
                return -1; // Invalid operator get outta hereeee
        }
    }
    private boolean isLeftAssociative(String operator) {
        // Return true if the operator is left associative
        return !operator.equals("^");
    }

}
