import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
/*
 * Author: Nathan LaBeff
 * Date: 09/19/23
 * A project intended to sort Vertex, Adjacent Vertices, find the topological order of an input file, as well as print
 * out said information.
 */

public class TopologicalSort {
    private class VertexNode {
        private final String name;
        private VertexNode nextV; //reference to the next vertex
        private EdgeNode edges; //head of the edge list for the vertex
        //the edge lists are sorted in ascending order
        //based of the name of the second vertex in the edge
        private int indegree;

        private VertexNode(String n, VertexNode v) {
            name = n;
            nextV = v;
            edges = null;
            indegree = 0;
        }
    }

    private class EdgeNode {
        private final VertexNode vertex1; //the edge (vertex1, vertex2)
        private final VertexNode vertex2;
        private EdgeNode nextE; //reference to the next edge in the edge list

        private EdgeNode(VertexNode v1, VertexNode v2, EdgeNode e) {
            vertex1 = v1;
            vertex2 = v2;
            nextE = e;
        }
    }

    private VertexNode vertices; //head of the list of vertices
    //the list of vertices is sorted
    // in ascending order based on the name
    private int numVertices;

    public TopologicalSort() {
        vertices = new VertexNode(null, null); //sentinel node
        numVertices = 0;
    }

    public void addVertex(String s) {
        // Insert a new vertex so the vertex list remains sorted in ascending order
        VertexNode v = new VertexNode(s, null);

        if (vertices == null) {
            vertices = v;
        } else {
            VertexNode current = vertices;
            while (current.nextV != null) {
                current = current.nextV;
            }
            current.nextV = v;
        }

        numVertices++;
    }


    public void addEdge(String n1, String n2) {
//PRE: the vertices n1 and n2 have already been added
//insert the new edge so the edge list remains sorted in ascending order
        VertexNode v1 = getVertex(n1);
        VertexNode v2 = getVertex(n2);

        if (v1 == null || v2 == null) {
            return;
        }

        EdgeNode newEdge = new EdgeNode(v1, v2, null);
        InsertEdge(v1, newEdge);
        v2.indegree++;
    }

    public void printGraph() {
        // Print the graph with tab-separated columns
        System.out.println("Vertex\tAdjacent Vertices");
        VertexNode current = vertices.nextV;
        while (current != null) {
            System.out.print(current.name + "\t\t");
            EdgeNode currentE = current.edges;
            while (currentE != null) {
                System.out.print(currentE.vertex2.name + " ");
                currentE = currentE.nextE;
            }
            System.out.println();
            current = current.nextV;
        }
    }

   public String topoSort() {
//return a string with the vertex names in a topological order
//if no topological order exists return the empty string
        Stack<String> topoStack = new Stack<String>();

        Queue<VertexNode> topoQueue = new LinkedList<VertexNode>();

        int count = 0;
        VertexNode current = vertices.nextV;
        while (current != null) {
            if (current.indegree == 0) {
                topoQueue.add(current);
            }
            current = current.nextV;
        }
        while (!topoQueue.isEmpty()) {
            VertexNode vertex = topoQueue.poll();
            topoStack.push(vertex.name);
            count++;

            EdgeNode edge = vertex.edges;
            while(edge != null) {
                edge.vertex2.indegree--;
                if(edge.vertex2.indegree == 0) {
                    topoQueue.add(edge.vertex2);
                }
                edge = edge.nextE;
            }
        }
        if (count != numVertices) {
            return "";
        }
        StringBuilder topOrder = new StringBuilder();
        while (!topoStack.isEmpty()) {
            topOrder.append(topoStack.pop()).append(" ");
        }
        return topOrder.toString();


    }

    //Helper methods
    private VertexNode getVertex(String name) {
        //Helper method I had made to get the vertex based on its name
        VertexNode current = vertices.nextV;
        VertexNode prev = vertices;

        while (current != null && !current.name.equals(name)) {
            current = current.nextV;
        }

        return current;
    }

    private void InsertEdge(VertexNode v, EdgeNode e) {
        //Helper method to insert an edge in order.
        EdgeNode current = v.edges;
        EdgeNode prev = null;

        //Loop that finds the previous edge in the edge list
        while (current != null && current.vertex2.name.compareTo(e.vertex2.name) > 0) {
            prev = current;
            current = current.nextE;
        }
        if(prev != null){
            prev.nextE = e;
        } else {
         v.edges = e;
        }
    e.nextE = current;
    }
}
