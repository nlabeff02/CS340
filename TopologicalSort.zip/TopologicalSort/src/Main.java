import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String args[]) throws IOException {
        //Simple Test Driver
        //This driver assumes the input file is formatted correctly
        BufferedReader b = new BufferedReader(new FileReader("./test.txt"));
        TopologicalSort g = new TopologicalSort();
        String line = b.readLine();
        Scanner scan = new Scanner(line);
        while (scan.hasNext()) {
            g.addVertex(scan.next());
        }
        line = b.readLine();
        while (line != null) {
            scan = new Scanner(line);
            g.addEdge(scan.next(), scan.next());
            line = b.readLine();
        }
        g.printGraph();
        String topoOrder = g.topoSort();
        if (topoOrder.isEmpty()) {
            System.out.println("\nNo topological order exists (cycle detected).");
        } else {
            System.out.println("\nTopological Order:\n" + topoOrder);
        }
    }
}