public class Main {
    public static void main(String[] args) {
        UndirectedGraph graph = new UndirectedGraph();

        // Adding vertices
        graph.addVertex("A");
        graph.addVertex("B");
        graph.addVertex("C");
        graph.addVertex("D");
        graph.addVertex("E");

        // Adding edges
        graph.addEdge("A", "B");
        graph.addEdge("B", "C");
        graph.addEdge("B", "D");
        graph.addEdge("D", "E");

        // Printing the graph
        System.out.println("Graph Structure:");
        graph.printGraph();

        // Performing BFS starting from vertex "A"
        String bfsResult = graph.bfs("A");
        System.out.println("\nBFS Starting from A:");
        System.out.println(bfsResult);
    }
}