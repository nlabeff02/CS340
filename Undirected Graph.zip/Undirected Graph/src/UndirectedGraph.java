import java.io.*;
import java.util.*;

//Nathan LaBeff
//Last Modified: Sept 26. 2023

public class UndirectedGraph {
    private class VertexNode {
        private String name;
        private VertexNode nextV; //next vertex in the vertex list
        private EdgeNode edges1; //head of the edge list 1 for this vertex
        private EdgeNode edges2; //head of the edge list 2 for this vertex
        private boolean queued;

        private VertexNode(String n, VertexNode v) {
            name = n;
            nextV = v;
            edges1 = null;
            edges2 = null;
            queued = false;
        }
    }

        private class EdgeNode {
            private VertexNode vertex1; //first vertex in the edge
            private VertexNode vertex2; //second vertex in the edge
            //vertex1.name < vertex2.name
            private EdgeNode nextE1; //next edge in edge list 1
            private EdgeNode nextE2; //next edge in edge list 2

            private EdgeNode(VertexNode v1, VertexNode v2) {
                //PRE: v1.name < v2.name
                vertex1 = v1;
                vertex2 = v2;
                nextE1 = null;
                nextE2 = null;
            }

            private void setNextE1(EdgeNode e) {
                nextE1 = e;
            }

            private void setNextE2(EdgeNode e) {
                nextE2 = e;
            }
        }
        private VertexNode vertices; //head of the vertex list

        public UndirectedGraph() {
            vertices = null; //the vertex list is initially empty(no sentinel node is used)
            int numVertices = 0;
        }

        public void addVertex(String s) {
        //PRE: The vertex list is sorted in ascending order (based on the name)
         /* insert a new vertex into the vertex list and
         keep the vertex list sorted in ascending order (based on the name)
         */
        VertexNode newV = new VertexNode(s, null);
        if (vertices == null || s.compareTo(vertices.name)<0) {
            newV.nextV = vertices;
            vertices = newV;
        } else{
            VertexNode currentV = vertices;
            while (currentV.nextV != null && s.compareTo(currentV.nextV.name) <= 0) {
                currentV = currentV.nextV;
            }
            newV.nextV = currentV.nextV;
            currentV.nextV = newV;

        }


        }

        public void addEdge(String n1, String n2) {
        /*PRE: the vertices with names n1 and n2 have already been added
        and the edge list 1 for lesser of n1 and n2 is sorted in
         ascending order based on the greater of n1 and n2
         and the edge list 2 for the greater of n1 and n2
         is sorted in ascending order based on the lesser of n1 and n2
         */
         /* add the new edge to the adjacency list and keep the edge lists sorted
         see the diagrams on the previous slides for more details
         */
            VertexNode vertex1 = FindV(n1);
            VertexNode vertex2 = FindV(n2);

            if (vertex1 == null || vertex2 == null) {
                return;
            }
            String lesserName;
            String greaterName;
            if (vertex1.name.compareTo(vertex2.name) < 0) {
                lesserName = vertex1.name;
                greaterName = vertex2.name;
            }else {
                greaterName = vertex2.name;
                lesserName = vertex1.name;
            }

            EdgeNode newE = new EdgeNode(vertex1, vertex2);

            addEdgeToVertexList(vertex1, newE, greaterName);
            addEdgeToVertexList(vertex2, newE, lesserName);


        }

        private void addEdgeToVertexList(VertexNode vertex, EdgeNode newE, String target){
            EdgeNode currentE = vertex.edges1;
            EdgeNode prevE = null;

            while(currentE != null && target.compareTo(currentE.vertex1.name) <= 0){
                prevE = currentE;
                currentE = currentE.nextE1;
            }
            if (prevE == null) {
                newE.nextE1 = vertex.edges1;
                vertex.edges1 = newE;
            } else{
                prevE.nextE1 = newE;
                newE.nextE1 = currentE;
            }
        }

        private VertexNode FindV(String n) {
            VertexNode currentV = vertices;
            while (currentV!= null && currentV.name!= n) {
                currentV = currentV.nextV;
            }
            if (currentV!= null) {
                return currentV;
            } else {
                return null;
            }
        }
    public String bfs(String v) {
        Queue<VertexNode> vertexNodeQueue = new LinkedList<>();
        StringBuilder bfsOrder = new StringBuilder();
        int counter = 0;

        // Reset the 'queued' flag for all vertices in the graph
        VertexNode currentV = vertices;
        while (currentV != null) {
            currentV.queued = false;
            currentV = currentV.nextV;
        }

        // Find the starting vertex with name 'v' and add it to the queue
        currentV = vertices;
        while (currentV != null) {
            if (currentV.name.equals(v)) {
                vertexNodeQueue.add(currentV);
                currentV.queued = true;
                break;
            }
            currentV = currentV.nextV;
        }

        while (!vertexNodeQueue.isEmpty()) {
            VertexNode x = vertexNodeQueue.poll();
            bfsOrder.append(x.name + " ");
            counter++;

            EdgeNode currentE = x.edges1;
            while (currentE != null) {
                VertexNode adjVertex = currentE.vertex2;

                if (!adjVertex.queued) {
                    vertexNodeQueue.add(adjVertex);
                    adjVertex.queued = true;
                }

                currentE = currentE.nextE1;
            }
        }
        return bfsOrder.toString().trim();
    }

    public void printGraph() {
        VertexNode currentV = vertices;

        while (currentV != null) {
            System.out.print("Node: " + currentV.name + " Edges1:");

            // Print edges1 (adjacent vertices of currentV)
            EdgeNode currentE1 = currentV.edges1;
            while (currentE1 != null) {
                System.out.print(" " + currentE1.vertex2.name);
                currentE1 = currentE1.nextE1;
            }

            System.out.print(" Edges2:");

            // Print edges2 (adjacent vertices of currentV)
            EdgeNode currentE2 = currentV.edges2;
            while (currentE2 != null) {
                System.out.print(" " + currentE2.vertex1.name);
                currentE2 = currentE2.nextE2;
            }

            System.out.println(); // Move to the next line for the next vertex
            currentV = currentV.nextV;
        }
    }


}
