import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Stack;

/**
 * Last Edited: Weds Dec. 6th
 * Author: Nathan LaBeff
 */


public class BTree {
    RandomAccessFile f;
    int order;
    int blockSize;
    long root;
    long free;
    //add instance variables as needed
    Stack<BTreeNode> paths;
    static int stopper = 0;
    int mid;

    private class BTreeNode {
        private int count;
        private int keys[];
        private long children[];
        private long addr;
        //constructors and other method

        // Constructor initializing from parameters
        // Constructor initializing from parameters
        private BTreeNode(int c, int[] k, long[] childs, long addr) {
            this.count = c;
            this.keys = k != null ? Arrays.copyOf(k, k.length) : new int[order - 1];
            this.children = childs != null ? Arrays.copyOf(childs, childs.length) : new long[order];
            this.addr = addr;
        }

        // Constructor reading from file
        private BTreeNode(long addr) {
            if (addr != 0) {
                this.keys = new int[order - 1];
                this.children = new long[order];
                try {
                    f.seek(addr);
                    this.addr = addr;
                    count = f.readInt();
                    for (int i = 0; i < order - 1; i++) {
                        keys[i] = f.readInt();
                    }
                    for (int i = 0; i < order; i++) {
                        children[i] = f.readLong();
                    }
                } catch (EOFException e) {
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        /**
         * Writes the B-tree node's data to the underlying storage at the specified address.
         */
        private void writeNode() {
            if (children == null) {
                return;
            } else {
                try {
                    f.seek(addr);

                    f.writeInt(count);
                    for (int i = 0; i < order - 1; i++) {
                        f.writeInt(keys[i]);
                    }
                    for (int i = 0; i < order; i++) {
                        f.writeLong(children[i]);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        /**
         * Creates a copy of the B-tree node with the same data and structure.
         *
         * @return A new B-tree node that is a copy of the current node.
         */
        // Copy method
        private BTreeNode copy() {
            if (this.keys == null) {
                this.keys = new int[order - 1];
            }
            return new BTreeNode(this.count, this.keys, this.children, this.addr);
        }


        private boolean isLeaf() {
            return count < 0;
        }

        /**
         * Returns the number of keys in the B-tree node.
         *
         * @return The number of keys in the node.
         */
        public int size() {
            return Math.abs(count);
        }

        /*
        Checks if there is enough space in the node for more keys.
         */
        private boolean hasSpace() {
            return Math.abs(count) < order - 1;
        }

        private boolean isTooSmall() {
            if (this.addr == root) {
                return count < 1;
            }
            return Math.abs(count) < minKeys();
        }

        /**
         * Calculates the minimum number of keys required in a B-tree node.
         */
        private int minKeys() {
            return (int) (Math.ceil(order / 2));
        }

        private boolean mergingRoot() {
            return addr == root && count == 1;
        }

        private long borrowFrom(BTreeNode unchanged, int key) {
            int i = 0;
            for (i = 0; i < Math.abs(count); i++) {
                if (key < keys[i]) {
                    break;
                }
            }
            long status = 0;
            if (i != Math.abs(count) && Math.abs(new BTreeNode(children[i + 1]).count) > minKeys()) {
                status = children[i + 1];
            }
            if (i != 0 && Math.abs(new BTreeNode(children[i - 1]).count) > minKeys()) {
                status = children[i - 1] * -1;
            }


            return status;
        }

        private boolean canBorrow(BTreeNode child, int key) {
            return borrowFrom(child, key) != 0;
        }

        private int findKeyIndex(int k) {
            for (int i = 0; i < Math.abs(count); i++) {
                if (k == keys[i]) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        public String toString() {
            String str = Long.toString(addr);
            str += " |Count|: " + count + " |Keys|: ";
            for (int key : keys) {
                str += " " + key;
            }
            str += " |Children|: ";
            for (long children : children) {
                str += " " + children;
            }

            return str;
        }

        /**
         * Determines if borrowing is possible from neighboring nodes in the B-tree to maintain balance.
         */
        public void insertEntry(int key, long addr) {
            // Find the position to insert

            // Return value:
            //  0: No borrowing possible
            //  Positive: Borrow from the right neighbor
            //  Negative: Borrow from the left neighbor (multiplied by -1)
            int i;
            for (i = 0; i < this.size(); i++) {
                if (key < keys[i]) {
                    break;
                }
            }

            // Shift keys and children to make room for the new key
            for (int j = this.size(); j > i; j--) {
                keys[j] = keys[j - 1];
                children[j + 1] = children[j];
            }
            // Insert the new key and child
            keys[i] = key;
            children[i + 1] = addr;

            // Update the count of keys in the node
            if (this.isLeaf()) {
                this.count = -(Math.abs(this.count) + 1);
            } else {
                this.count = Math.abs(this.count) + 1;
            }
        }


        // removeEntry method
        private long removeEntry(int key) {
            if (children == null) {

                return -1;
            } else {
                int k = !isLeaf() ? 1 : 0;
                int j = findKeyIndex(key);
                long retVal = children[j];
                for (j = findKeyIndex(key); j < order - 2; j++) {
                    keys[j] = keys[j + 1];
                    children[j + k] = children[j + 1 + k];
                }

                if (isLeaf()) {
                    count++;
                } else {
                    count--;
                }
                return retVal;
            }
        }

        /**
         * Removes an entry with the given key from the B-tree node and returns the child address.
         */
        private long removeEntry(int key, int childOffset) {
            int j = findKeyIndex(key);
            long retVal = children[j];
            for (j = findKeyIndex(key); j < order - 2; j++) {
                keys[j] = keys[j + 1];
                children[j + childOffset] = children[j + 1 + childOffset];
            }

            if (isLeaf()) {
                count++;
            } else {
                count--;
            }
            return retVal;
        }

        /**
         * Splits the current B-tree node into two nodes and returns the newly created node.
         */
        private BTreeNode split(int key, long addr) {

            BTreeNode splitNode = new BTreeNode(count, Arrays.copyOf(keys, order), Arrays.copyOf(children, order + 1), this.addr);

            if (key != -1 && addr != -1) {
                splitNode.insertEntry(key, addr);
            }
            int newCount = (int) Math.ceil((double) splitNode.keys.length / 2);

            int callerNewCount = Math.abs(count) + 1 - newCount;
            if (isLeaf()) {
                count = callerNewCount * -1;
            } else {
                count = callerNewCount;
            }
            long link = children[order - 1];

            keys = Arrays.copyOf(Arrays.copyOfRange(splitNode.keys, 0, Math.abs(count)), order - 1);
            children = Arrays.copyOf(Arrays.copyOfRange(splitNode.children, 0, Math.abs(count) + 1), order);

            int[] keyArr = Arrays.copyOf(Arrays.copyOfRange(splitNode.keys, newCount - 1, splitNode.keys.length), order - 1);
            long[] childrenArr = Arrays.copyOf(Arrays.copyOfRange(splitNode.children, newCount - 1, splitNode.children.length), order);

            if (order % 2 == 0 || !splitNode.isLeaf()) {
                mid = keyArr[0];
                keyArr = Arrays.copyOf(Arrays.copyOfRange(splitNode.keys, newCount, splitNode.keys.length), order - 1);
                childrenArr = Arrays.copyOf(Arrays.copyOfRange(splitNode.children, newCount, splitNode.children.length), order);
                if (order % 2 == 1) {
                    newCount--;
                }

            }

            if (splitNode.isLeaf()) {
                newCount *= -1;
            }

            childrenArr[order - 1] = link;
            BTreeNode newnode = new BTreeNode(newCount, keyArr, childrenArr, getFree());
            children[order - 1] = newnode.addr;

            return newnode;
        }

        /**
         * Borrowing between B-tree nodes to maintain balance after a removal.
         */
        private void borrow(BTreeNode r, BTreeNode unchanged, int key) {
            long status = r.borrowFrom(unchanged, key);
            BTreeNode neighbor = null;
            int splitCount = 0;
            if (status < 0) {
                neighbor = new BTreeNode(status * -1);
                splitCount = (int) Math.ceil((double) (Math.abs(neighbor.count) - minKeys()) / 2);
                int i = 0;
                int count = Math.abs(neighbor.count);
                if (!isLeaf()) {
                    splitCount = 1;

                    for (int k = Math.abs(unchanged.count); k >= 0; k--) {
                        keys[k + 1] = keys[k];
                        children[k + 1] = children[k];
                    }
                    keys[0] = r.keys[r.count - 1];
                    children[0] = neighbor.children[neighbor.count];
                    this.count++;
                    r.keys[r.count - 1] = neighbor.keys[neighbor.count - 1];
                    for (i = count - 1; i > count - splitCount - 1; i--) {
                        neighbor.removeEntry(neighbor.keys[i]);
                    }
                } else {

                    for (i = count - 1; i > count - splitCount - 1; i--) {
                        insertEntry(neighbor.keys[i], neighbor.children[i]);
                    }
                    for (i = count - 1; i > count - splitCount - 1; i--) {
                        neighbor.removeEntry(neighbor.keys[i]);
                    }
                }
                if (isLeaf()) {
                    for (i = 0; i < Math.abs(r.count); i++) {
                        if (unchanged.keys[0] < r.keys[i]) {
                            break;
                        }
                    }
                    r.keys[i - 1] = keys[0];
                }
            } else {

                neighbor = new BTreeNode(status);
                splitCount = (int) Math.ceil((double) (Math.abs(neighbor.count) - minKeys()) / 2.0);
                for (int i = 0; i < splitCount; i++) {
                    insertEntry(neighbor.keys[i], neighbor.children[i]);
                }
                for (int i = 0; i < splitCount; i++) {
                    neighbor.removeEntry(neighbor.keys[i]);
                }

                if (isLeaf()) {
                    int i = 0;
                    for (i = 0; i < Math.abs(r.count); i++) {
                        if (neighbor.keys[0] < r.keys[i]) {
                            break;
                        }
                    }
                    if (i == 0) {
                        r.keys[r.count - 1] = neighbor.keys[0];
                    } else {
                        r.keys[i - 1] = neighbor.keys[0];
                    }
                }
            }
            r.writeNode();
            neighbor.writeNode();
            writeNode();

        }

        /**
         * Combines the current B-tree node with a child node when they are too small, ensuring balanced merging.
         */
        private void combine(BTreeNode child) {
            int i = 0;
            for(i = 0; i < Math.abs(count); i++) {
                if (child.addr == children[i]) {
                    break;
                }
            }
            BTreeNode neighbor = null;

            if(mergingRoot()) {
                BTreeNode merge = new BTreeNode(children[i]);
                long childAddr = 0;
                if(i == 0) {
                    childAddr = merge.children[1];
                } else {
                    childAddr = merge.children[0];

                }
                child.insertEntry(keys[0], childAddr);
            }

            if(i == 0) {
                removeEntry(keys[0],0);
            } else {
                removeEntry(keys[i-1]);
            }

            if(i == 0) {
                i = 2;
            }
            neighbor = new BTreeNode(children[i - 1]);

            for(int j = 0; j < Math.abs(child.count); j++) {
                neighbor.insertEntry(child.keys[j], child.children[j]);
            }

            if(!child.isLeaf()) {
                neighbor.children[order-1] = child.children[child.count];
            } else {
                neighbor.children[order-1] = child.children[order-1];
            }

            addFree(child.addr);
            writeNode();
            child.writeNode();
            neighbor.writeNode();
        }

    }

        public BTree(String filename, int bsize) {
        //bsize is the block size. This value is used to calculate the order
//of the B+Tree
//all B+Tree nodes will use bsize bytes
//makes a new B+tree
        try {
            File path = new File(filename);
            if (path.exists()) {
                path.delete();
            }
            f = new RandomAccessFile(path,"rw");
            root = 0;
            free = 0;
            blockSize = bsize;
            order = bsize / 12;
            paths = new Stack<>();
            f.seek(0);
            f.writeLong(root);
            f.writeLong(free);
            f.writeInt(blockSize);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public BTree(String filename) {
        //open an existing B+Tree
        try {
            f = new RandomAccessFile(filename,"rw");
            f.seek(0);
            root = f.readLong();
            free = f.readLong();
            blockSize = f.readInt();
            order = blockSize/12;
            paths = new Stack<>();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean insert(int key, long addr) {
        /*
If key is not a duplicate add key to the B+tree
addr (in DBTable) is the address of the row that contains the key
return true if the key is added
return false if the key is a duplicate
*/
        if (root == 0) {
            insertRoot(key,addr);
            return true;
        }
        boolean inTable = 0 != search(key);
        boolean split = false;
        if(!inTable) {
            long loc = 0;
            int val = 0;
            BTreeNode r = paths.pop();

            if (r.hasSpace()) {
                r.insertEntry(key,addr);
                r.writeNode();
            } else {
                BTreeNode newnode = r.split(key,addr);

                val = newnode.keys[0];
                r.writeNode();
                newnode.writeNode();
                loc = newnode.addr;
                split = true;
            }

            while (!paths.empty() && split) {
                BTreeNode node = paths.pop();
                if(node.hasSpace()) {
                    node.insertEntry(val, loc);
                    node.writeNode();
                    split = false;
                } else {
                    BTreeNode newnode = node.split(val, loc);
                    val = mid;
                    loc = newnode.addr;
                    node.writeNode();
                    newnode.writeNode();

                    split = true;
                }
            }//End while
            if (split) { //Then root was split
                int[] keys = new int[order-1];
                long[] children = new long[order];
                keys[0] = val;
                children[0] = root;
                children[1] = loc;
                BTreeNode newnode = new BTreeNode(1,keys,children,getFree());
                root = newnode.addr;


                newnode.writeNode();
            }
        }

        return !inTable;
    }

    private void insertRoot(int key, long addr) {
        int[] keys = new int[order-1];
        long[] children = new long[order];
        keys[0] = key;
        children[0] = addr;
        BTreeNode r = new BTreeNode(-1,keys,children,getFree());
        r.writeNode();
        root = r.addr;
    }
    public long remove(int key) {
        /*
If the key is in the Btree, remove the key and return the address of the
row
return 0 if the key is not found in the B+tree
*/

        if (paths.isEmpty()) {
            searchToLeaf(key);
            if (paths.isEmpty()) {
                return 0;
            }
        }

        BTreeNode r = paths.pop();
        BTreeNode unchanged = r.copy();
        long retVal = r.removeEntry(key);
        r.writeNode();
        boolean tooSmall = r.isTooSmall();

        while (!paths.empty() && tooSmall) {
            BTreeNode child = r;
            unchanged = r.copy();
            r = paths.pop();

            if(r.canBorrow(unchanged, key)) {
                child.borrow(r, unchanged, key);
                tooSmall = false;
            } else {
                r.combine(child);
                tooSmall = r.isTooSmall();
            }
        }

        if(tooSmall) {
            root = r.children[0];
        }

        return retVal;
    }

    private BTreeNode searchToLeaf(int k) {
        int i = 0;
        paths = new Stack<>();
        BTreeNode r = new BTreeNode(root);
        paths.push(r);
        if (root == 0) {
            return r;
        }
        while (!r.isLeaf() && r.children != null) {
            for (i = 0; i <= Math.abs(r.count); i++) {
                if (i == Math.abs(r.count) || k < r.keys[i]) {
                    r = new BTreeNode(r.children[i]);
                    paths.push(r);
                    break;
                }
            }
        }
        return r;
    }


    public long search(int k) {
        /*
This is an equality search
If the key is found return the address of the row with the key
otherwise return 0
*/
        BTreeNode r = searchToLeaf(k);
        if(root == 0) {
            return 0;
        }
        long addr = 0;

        int i = r.findKeyIndex(k);

        if(i != -1) {
            addr = r.children[i];
        }

        return addr;
    }
    public LinkedList<Long> rangeSearch(int low, int high) {
        //PRE: low <= high
/*
return a list of row addresses for all keys in the range low to high inclusive
the implementation must use the fact that the leaves are linked
return an empty list when no keys are in the range
*/
        LinkedList<Long> list = new LinkedList<>();
        BTreeNode r = searchToLeaf(low);
        int i = 0;
        if(r.keys != null) {
            while (i < r.keys.length && r.keys[i] < high) {
                list.add(r.children[i]);
                i++;
                if (i == r.count * -1) {
                    if (r.children[order - 1] == 0) {
                        break;
                    }
                    r = new BTreeNode(r.children[order - 1]);
                    i = 0;
                }
            }
        }
        return list;
    }
    private long getFree() {
        long addr = 0;
        try {
            if (free == 0) {
                addr = f.length();
            } else {

                f.seek(free);
                free = f.readLong();
                addr = free;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return addr;
    }

    private void addFree(long addr){
        try {
            f.seek(addr);
            f.writeLong(free);
            free = addr;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void print() {
        //print the B+Tree to standard output
//print one node per line
//This method can be helpful for debugging
        try {
            f.seek(20);
            System.out.println("|Root|: " + root);
            System.out.println("|Free|: " + free);
            while(f.getFilePointer() < f.length()) {
                BTreeNode n = new BTreeNode(f.getFilePointer());
                System.out.println("|Addr|: " + n);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void close() {
        try {
            //close the B+tree. The tree should not be accessed after close is called
            f.seek(0);
            f.writeLong(root);
            f.writeLong(free);
            f.writeInt(blockSize);
            f.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

