public class BTreeTestDriver {
    public static void main(String[] args) {
        int blockSize = 128; // Adjust blockSize as needed for your B-tree
        BTree btree = new BTree("btree.dat", blockSize);

        int[] keysToInsert = {15, 6, 23, 9, 4, 17, 12};
        int[] keysToRemove = {9, 17, 6};

        long address = 1000; // Starting address for testing

        // Insert keys and print tree structure
        for (int key : keysToInsert) {
            btree.insert(key, address);
            address += 100; // Increment the address for next insertion
            System.out.println("After inserting key " + key + ":");
            btree.print();
        }

        // Remove keys and print tree structure
        for (int key : keysToRemove) {
            btree.remove(key);
            System.out.println("After removing key " + key + ":");
            btree.print();
        }

        // Test search function
        for (int key : keysToInsert) {
            long searchAddress = btree.search(key);
            System.out.println("Search for key " + key + ": " + (searchAddress != 0 ? "Found at address " + searchAddress : "Not found"));
        }

        // Search for a key that doesn't exist
        System.out.println("Search for a non-existing key (e.g., 100): " + (btree.search(100) != 0 ? "Found" : "Not found"));

        btree.close();
    }
}
