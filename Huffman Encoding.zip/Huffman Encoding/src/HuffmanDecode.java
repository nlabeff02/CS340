import java.io.*;
import java.util.*;

public class HuffmanDecode {


	public HuffmanDecode(String in, String out) {
	//implements the Huffman Decode Algorithm
	//Add private methods and instance variables as needed
		try{
			decodeFile(in, out);
		}catch(IOException e){
			System.out.println("Error reading file in decoding process.");
		}

	}

	public static void main(String args[]) {
	//args[0] is the name of a input file (a file created by Huffman Encode)
	//args[1] is the name of the output file for the uncompressed file
		new HuffmanDecode(args[0], args[1]);
    //do not add anything here
	}
	private void decodeFile(String in, String out) throws FileNotFoundException {
		try {

			HuffmanInputStream his = new HuffmanInputStream(in);
			PrintWriter pw = new PrintWriter(out);

			HuffmanTree ht = new HuffmanTree(his.getTree(), (char) 128);
			int chars = 0;
			int y = -1;

			while (chars != his.getTotalChars()) {
				if (!ht.atLeaf()) {
					y = his.readBit();
					if (y == 0) {
						ht.moveToLeft();
					} else {
						ht.moveToRight();
					}
				} else {
					chars++;
					pw.write(ht.current());
					ht.moveToRoot();
				}
			}
			pw.close();
			his.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found in decodeFile!");
		}

	}
}
