import java.io.*;
import java.util.*;

public class HuffmanEncode {

	//Integer for total chars
	//Instantiating the PriorityQueue
	private int ttlChar;
	private PriorityQueue<Item> pQueue;


	private class Item implements Comparable<Item>{
		private int frequency;
		private HuffmanTree data;

		//constructor
		private Item(int f, HuffmanTree d){
			frequency = f;
			data = d;
		}
		//Replace compareTo so that you can evaluate the difference in frequency
		@Override
		public int compareTo(Item it){
			return this.frequency - it.frequency;
		}

		@Override
		public String toString(){
			String freqDataStr = "Frequency: " + this.frequency +
					" Data: " + this.data.toString();
			return freqDataStr;
		}

	}
	public HuffmanEncode(String in, String out) {
	//Implements the huffman encoding algorithm
	//Add private methods and instance variables as needed
		pQueue = new PriorityQueue<>(128);
		ttlChar = 0;

		readIn(in);
		buildTree();
		writeOut(in, out);
	}


	public static void main(String args[]) {
	//args[0] is the name of the file whose contents should be compressed
	//args[1] is the name of the output file that will hold the compressed content of the input file
		new HuffmanEncode(args[0], args[1]);
        //do not add anything here
	}

	//Method to read in the designated file and add to a queue, so it may later be written out.
	private void readIn(String inFile){
		int[] arr = new int[128];
		try{
			BufferedReader br = new BufferedReader(new FileReader(inFile));
			int x = 0;
			while((x = br.read()) != -1){
				arr[x]++;
				ttlChar++;
			}
			for(int i = 0; i < arr.length; i++){
				if(arr[i] != 0){
					pQueue.add(new Item(arr[i], new HuffmanTree((char)i)));
				}
			}
			br.close();
		}catch(IOException e){
			System.out.println("IOError while reading in file");
		}

	}
	//Method to write out files to the designated file.
	private void writeOut(String inFile, String outFile) {
		String[] strArr = new String[128];

		HuffmanTree ht = pQueue.poll().data;
		Iterator<String> it = ht.iterator();

		while(it.hasNext()) {
			String str = it.next();
			strArr[str.charAt(0)] = str.substring(1);
		}

		try {
			//Create reader writer
			HuffmanOutputStream writer = new HuffmanOutputStream(outFile,ht.toString(), ttlChar);
			BufferedReader reader = new BufferedReader(new FileReader(inFile));

			int y = 0;
			while((y = reader.read()) != -1) {
				//Write encodings
				for(int i = 0; i < strArr[y].length(); i++) {
					char bit = strArr[y].charAt(i);
					writer.writeBit(bit);
				}
			}
			writer.close();
			reader.close();
		} catch (IOException e) {
			System.out.println("IO Error in writing out!");
		}

	}

	//Populates an Item with values from the priority queue to construct a huffmanTree.
	private void buildTree(){
		while(pQueue.size() > 1){
			Item left = pQueue.poll();
			Item right = pQueue.poll();
			Item merged = new Item(left.frequency + right.frequency, new HuffmanTree(left.data, right.data, (char)128));

			pQueue.add(merged);
		}
	}


}