import java.util.*;

/**
 * Nathan LaBeff
 * Last edited: [11/20/23]
 * Java class for the HuffmanTree data structure.
 */


public class HuffmanTree {
//DO NOT include the frequency or priorty in the tree

	private class Node {
		private Node left;
		private char data;
		private Node right;
        private Node parent;

		private Node(Node L, char d, Node R, Node P) {
			left = L;
			data = d;
			right = R;
            parent = P;
		}

	}

	private Node root;
	private Node current; //this value is changed by the move methods

	public HuffmanTree() {
		root = null;
		current = null;
	}

	public HuffmanTree(char d) {
	//makes a single node tree
		current = new Node(null, d, null, null);
		root = current;
	}

	public HuffmanTree(String t, char nonLeaf) {
	//Assumes t represents a post order representation of the tree as discussed in class
	//nonLeaf is the char value of the data in the non-leaf nodes
    //in classs we used (char) 128 for the non-leaf value

		char huffArr[] = t.toCharArray();
		Stack<HuffmanTree> huffStack = new Stack<>();
		for(int i = 0; i < huffArr.length; i++) {
			if (huffArr[i] == nonLeaf) {

				HuffmanTree rightI = huffStack.pop();
				HuffmanTree leftI = huffStack.pop();

				huffStack.push(new HuffmanTree(leftI, rightI, nonLeaf));
			}else{
				huffStack.push(new HuffmanTree(huffArr[i]));
				}

			}
		current = huffStack.pop().root;
		root = current;
	}

	public HuffmanTree(HuffmanTree b1, HuffmanTree b2, char d) {
	//makes a new tree where b1 is the left subtree and b2 is the right subtree
	//d is the data in the root
		current = new Node(b1.root, d, b2.root, null);
		root = current;
	}

	//use the move methods to traverse the tree
	//the move methods change the value of current
    //use these in the decoding process

	public void moveToRoot() {
    //change current to reference the root of the tree
		current = root;
	}

	public void moveToLeft() {
    //PRE: the current node is not a leaf
    //change current to reference the left child of the current node
		current = current.left;
	}

	public void moveToRight() {
    //PRE: the current node is not a leaf
    //change current to reference the right child of the current node
		current = current.right;
	}

    public void moveToParent() {
    //PRE: the current node is the root
    //change current to reference the parent of the current node
		current = current.parent;
    }

    public boolean atRoot() {
    //returns true if the current node is the root otherwise returns false
		return current == root;
    }

	public boolean atLeaf() {
	//returns true if current references a leaf other wise returns false
		return current.left == null && current.right == null;

	}

	public char current() {
	//returns the data value in the node referenced by current
	return current.data;

	}

    public String[] pathsToLeaves() {
    /*returns an array of strings with all paths from the root to the leaves
      each value in the array contains a leaf value followed by a seqeunce of
      0s and 1s. The 0s and 1s represent the path from the root to the node
      containing the leaf value.
    */
		if (root == null) {
			return new String[0]; // Return an empty array if the tree is empty
		}
		List<String> paths = new ArrayList<>();
		findPaths(root, "", paths);
		return paths.toArray(new String[0]);
    }

	// Recursive helper method to find paths (just for pathsToLeaves)
	private void findPaths(Node node, String path, List<String> paths) {
		if (node.left == null && node.right == null) {
			// When a leaf node is reached, add the path to the list
			paths.add(path + node.data); // Appending the character itself to its path
		} else {
			// Go left and append '0' to the path
			if (node.left != null) {
				findPaths(node.left, path + "0", paths);
			}
			// Go right and append '1' to the path
			if (node.right != null) {
				findPaths(node.right, path + "1", paths);
			}
		}
	}

	/**
	 * PathIterator provides an iterator over binary tree paths.
	 * It stores paths as strings of 0s and 1s representing traversal directions.
	 */
	public class PathIterator implements Iterator<String> {
		private LinkedList<String> paths;

		// Initializes the list of paths from the root of the binary tree.
		public PathIterator() {
			paths = new LinkedList<>();
			createPath(root,"");
		}
		// Recursively builds paths from the root to each leaf node.
		private void createPath(Node n, String path) {
			if(n.left == null) {
				paths.add(n.data + path);
				return;
			}
			createPath(n.left, path + "0");
			createPath(n.right, path + "1");
		}
		// Returns the next path in the list, if available.
		public String next() {
			return paths.poll();

		}
		public boolean hasNext() {
			return !paths.isEmpty();

		}
	}

	public Iterator<String> iterator() {
		return new PathIterator();
	}


	// Helper method to check if a node is a leaf
	private boolean isLeaf(Node node) {
		return node.left == null && node.right == null;
	}


	private String toString(Node node){
		if (node == null){
			return "";
		}
		String leftStr = toString(node.left);
		String rightStr = toString(node.right);

		return leftStr + rightStr + node.data;
	}

	public String toString() {
		return toString(this.root);
	}

}

