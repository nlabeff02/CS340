public class HuffmanTestDriver {

    public static void main(String[] args) {
            //encode testing
            //new HuffmanEncode("book1.txt", "book1.enc");
            //new HuffmanEncode("book2.txt", "book2.enc");
            //new HuffmanEncode("book3.txt", "book3.enc");

            //decode testing
           new HuffmanDecode("book1.enc","book1new.txt");
            new HuffmanDecode("book2.enc","book2new.txt");
           // new HuffmanDecode("book3.enc", "book3new.txt");


    }
}